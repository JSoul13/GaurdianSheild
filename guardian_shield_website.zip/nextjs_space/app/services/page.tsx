import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Search, FileSearch, Shield, Users, Building2, TrendingUp, Lock, Monitor, AlertTriangle, Database, User, Car, MapPin, Plane } from 'lucide-react'

export default function ServicesPage() {
  const serviceCategories = [
    {
      id: 'private-investigation',
      icon: Search,
      title: 'Private Investigation',
      description: 'Our private investigation services combine traditional investigative techniques with modern technology to uncover the truth. Whether you need surveillance, background verification, or locating individuals, our experienced investigators handle each case with the utmost discretion and professionalism.',
      image: 'https://cdn.abacus.ai/images/009d5caf-a2d3-45b5-96f2-97ad0f3b75d3.png',
      services: [
        { icon: Users, name: 'Infidelity & Matrimonial Investigations', desc: 'Discreet surveillance and evidence gathering for domestic matters' },
        { icon: FileSearch, name: 'Background Checks & Due Diligence', desc: 'Comprehensive background verification for personal and professional decisions' },
        { icon: Shield, name: 'Insurance Fraud Investigation', desc: 'Uncovering fraudulent insurance claims and false injury cases' },
        { icon: MapPin, name: 'Missing Persons & Locates', desc: 'Expert skip tracing and person location services' },
        { icon: Monitor, name: 'Surveillance & Activity Checks', desc: 'Professional surveillance operations with photographic and video evidence' }
      ]
    },
    {
      id: 'corporate-security',
      icon: Building2,
      title: 'Corporate & Financial Security',
      description: 'Protect your business from internal and external threats. Our corporate security services help organizations identify vulnerabilities, investigate misconduct, conduct due diligence, and safeguard their most valuable assets—intellectual property, reputation, and financial integrity.',
      image: 'https://cdn.abacus.ai/images/fc936f68-38cd-434b-8cda-1e15943127af.png',
      services: [
        { icon: AlertTriangle, name: 'Internal Theft & Fraud Investigations', desc: 'Investigate employee misconduct, embezzlement, and corporate fraud' },
        { icon: Lock, name: 'Intellectual Property Protection', desc: 'Safeguard trade secrets, patents, and proprietary information' },
        { icon: TrendingUp, name: 'Due Diligence for Mergers/Acquisitions', desc: 'Comprehensive background research for business transactions' },
        { icon: Users, name: 'Workplace Misconduct Investigations', desc: 'HR investigations for harassment, discrimination, and policy violations' }
      ]
    },
    {
      id: 'protection-services',
      icon: Shield,
      title: 'Protection Services',
      description: 'Your safety is paramount. Our executive protection team provides discreet, professional security solutions for individuals, families, and corporate assets, ensuring peace of mind at home, at work, and abroad. From close protection details to comprehensive security planning, we tailor our services to your unique risk profile.',
      image: 'https://cdn.abacus.ai/images/53b348fb-fb07-4d36-b468-8956345ba99d.png',
      services: [
        { icon: User, name: 'Executive & Close Protection', desc: 'Personal security details for high-profile individuals and executives' },
        { icon: Users, name: 'Event Security Planning', desc: 'Comprehensive security coordination for corporate and private events' },
        { icon: Building2, name: 'Asset & Property Security Reviews', desc: 'Physical security assessments and vulnerability analysis' },
        { icon: Plane, name: 'Travel Risk Assessment', desc: 'Pre-travel intelligence and security planning for domestic and international travel' }
      ]
    },
    {
      id: 'cyber-security',
      icon: Lock,
      title: 'Cyber Security & Digital Investigations',
      description: 'In today\'s digital world, threats are often invisible. Our cyber investigation team specializes in uncovering digital evidence, tracing online fraud, and securing your sensitive information from malicious actors. We employ advanced forensic tools to analyze devices, investigate cyber crimes, and respond to data breaches.',
      image: 'https://cdn.abacus.ai/images/f9a5f296-2c6e-4fba-9eaa-f9a571632286.png',
      services: [
        { icon: Database, name: 'Digital Forensics (Device Analysis)', desc: 'Forensic examination of computers, phones, and digital storage devices' },
        { icon: Shield, name: 'Cyber Threat Assessment', desc: 'Evaluate vulnerabilities and strengthen digital security posture' },
        { icon: AlertTriangle, name: 'Online Fraud & Harassment Investigation', desc: 'Track down cybercriminals, scammers, and online harassers' },
        { icon: Lock, name: 'Data Breach Response Support', desc: 'Emergency response and investigation for data security incidents' }
      ]
    }
  ]

  return (
    <div className="flex flex-col pt-20">
      {/* Header */}
      <section className="bg-gradient-to-r from-[#002855] to-[#36454F] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Our Services</h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Comprehensive security and investigation solutions tailored to protect your interests,
            resolve complex cases, and provide peace of mind.
          </p>
        </div>
      </section>

      {/* Service Categories */}
      {serviceCategories?.map?.((category, index) => (
        <section
          key={category?.id}
          id={category?.id}
          className={`py-20 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                <div className="relative aspect-video rounded-lg overflow-hidden shadow-lg bg-gray-100">
                  <Image
                    src={category?.image ?? ''}
                    alt={category?.title ?? ''}
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
              <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                <div className="flex items-center mb-4">
                  <category.icon className="h-10 w-10 text-[#60A5FA] mr-4" />
                  <h2 className="text-4xl font-bold text-[#002855]">{category?.title ?? ''}</h2>
                </div>
                <p className="text-lg text-[#36454F] mb-8">{category?.description ?? ''}</p>
                <div className="space-y-4">
                  {category?.services?.map?.((service, sIndex) => (
                    <div key={sIndex} className="flex items-start space-x-3 bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
                      <div className="flex-shrink-0">
                        <service.icon className="h-6 w-6 text-[#60A5FA] mt-1" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-[#002855] mb-1">{service?.name ?? ''}</h3>
                        <p className="text-sm text-[#36454F]">{service?.desc ?? ''}</p>
                      </div>
                    </div>
                  )) ?? []}
                </div>
              </div>
            </div>
          </div>
        </section>
      )) ?? []}

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-[#002855] to-[#60A5FA] text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8">
            Schedule a confidential consultation to discuss your specific needs and learn how we can help.
          </p>
          <Link href="/contact">
            <Button size="lg" className="bg-white text-[#002855] hover:bg-gray-100 px-8 py-6 text-lg">
              Contact Us Today
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
