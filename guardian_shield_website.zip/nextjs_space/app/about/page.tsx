import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Shield, Award, Users, Globe, Target, Heart, CheckCircle } from 'lucide-react'

export default function AboutPage() {
  const values = [
    {
      icon: Shield,
      title: 'Discretion',
      description: 'We understand the sensitive nature of our work. Every case is handled with the utmost confidentiality and professionalism.'
    },
    {
      icon: Target,
      title: 'Results-Oriented',
      description: 'Our focus is on delivering actionable intelligence and tangible outcomes that help resolve your situation.'
    },
    {
      icon: Heart,
      title: 'Ethical Practice',
      description: 'We conduct all investigations within the bounds of the law, maintaining the highest ethical standards in our industry.'
    }
  ]

  const differentiators = [
    {
      icon: Award,
      title: 'Law Enforcement Background',
      description: 'Led by former Police Commissioner Paul J. Italiano, bringing decades of experience and insider knowledge to every case.'
    },
    {
      icon: Globe,
      title: 'Advanced Technology',
      description: 'We leverage cutting-edge digital forensics, surveillance equipment, and investigative tools to gather the evidence you need.'
    },
    {
      icon: Users,
      title: 'Comprehensive Approach',
      description: 'From cyber investigations to physical protection, we offer a complete suite of services under one roof.'
    },
    {
      icon: CheckCircle,
      title: 'Professional Network',
      description: 'Members of WAD and IPIU with access to international resources and investigative partnerships worldwide.'
    }
  ]

  return (
    <div className="flex flex-col pt-20">
      {/* Header */}
      <section className="bg-gradient-to-r from-[#002855] to-[#36454F] text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">About Guardian Shield Inc.</h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            A trusted partner in private investigation and security services, dedicated to protecting
            what matters most to our clients.
          </p>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#002855] mb-6">Our Philosophy</h2>
            <p className="text-xl text-[#36454F] max-w-4xl mx-auto">
              At Guardian Shield Inc., we believe that every individual and organization deserves protection,
              clarity, and resolution when facing complex challenges. We combine traditional investigative
              excellence with modern technology to deliver results that make a difference.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values?.map?.((value, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-8 shadow-md hover:shadow-xl transition-all duration-300">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#60A5FA]/20 mb-6">
                  <value.icon className="h-8 w-8 text-[#60A5FA]" />
                </div>
                <h3 className="text-2xl font-bold text-[#002855] mb-4">{value?.title ?? ''}</h3>
                <p className="text-[#36454F]">{value?.description ?? ''}</p>
              </div>
            )) ?? []}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#002855] mb-6">Leadership</h2>
            <p className="text-xl text-[#36454F]">
              Experience, integrity, and unwavering commitment to client success
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-xl overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
                <div className="relative aspect-[3/4] bg-gray-100">
                  <Image
                    src="https://cdn.abacus.ai/images/42f28421-5a2d-463e-8cb2-ebec488fc6c0.png"
                    alt="Paul J. Italiano"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="md:col-span-2 p-8">
                  <h3 className="text-3xl font-bold text-[#002855] mb-2">Paul J. Italiano</h3>
                  <p className="text-lg text-[#60A5FA] font-semibold mb-6">Owner & President</p>
                  <div className="space-y-4 text-[#36454F]">
                    <p>
                      Paul J. Italiano is the founder and president of Guardian Shield Inc., bringing over two decades
                      of law enforcement and investigative experience to every case.
                    </p>
                    <p>
                      As the former <strong className="text-[#002855]">Police Commissioner of the Wappingers Falls Police Department</strong>,
                      Paul led complex investigations, managed critical security operations, and built strong
                      relationships with federal, state, and local agencies.
                    </p>
                    <p>
                      His transition from public service to private investigation was driven by a commitment to
                      provide the same level of excellence and integrity to individuals, families, and corporations
                      facing sensitive matters that require discretion and expertise.
                    </p>
                    <div className="pt-6 mt-6">
                      <Link href="/contact">
                        <Button className="bg-[#60A5FA] hover:bg-[#60A5FA]/90 text-white px-8 py-3">
                          Contact Us
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#002855] mb-6">Why Choose Guardian Shield Inc.?</h2>
            <p className="text-xl text-[#36454F]">
              The differentiators that set us apart in the private investigation industry
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {differentiators?.map?.((item, index) => (
              <div key={index} className="flex items-start space-x-4 bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300">
                <div className="flex-shrink-0">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#60A5FA]/20">
                    <item.icon className="h-6 w-6 text-[#60A5FA]" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#002855] mb-2">{item?.title ?? ''}</h3>
                  <p className="text-[#36454F]">{item?.description ?? ''}</p>
                </div>
              </div>
            )) ?? []}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-[#002855] to-[#60A5FA] text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Experience the Guardian Shield Difference</h2>
          <p className="text-xl mb-8">
            Let us put our expertise, technology, and network to work for you.
          </p>
          <Link href="/contact">
            <Button size="lg" className="bg-white text-[#002855] hover:bg-gray-100 px-8 py-6 text-lg">
              Schedule a Consultation
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
