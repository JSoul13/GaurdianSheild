'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import Link from 'next/link'
import Image from 'next/image'
import { Search, Building2, Shield, Lock, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function ServicesPreview() {
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 })

  const services = [
    {
      icon: Search,
      title: 'Private Investigation',
      description: 'Comprehensive investigative services including surveillance, background checks, infidelity investigations, and missing persons locates.',
      image: 'https://cdn.abacus.ai/images/009d5caf-a2d3-45b5-96f2-97ad0f3b75d3.png',
      href: '/services#private-investigation'
    },
    {
      icon: Building2,
      title: 'Corporate & Financial Security',
      description: 'Protect your business with internal fraud investigations, due diligence, intellectual property protection, and workplace misconduct resolution.',
      image: 'https://cdn.abacus.ai/images/fc936f68-38cd-434b-8cda-1e15943127af.png',
      href: '/services#corporate-security'
    },
    {
      icon: Shield,
      title: 'Protection Services',
      description: 'Executive protection, close protection details, event security planning, and comprehensive travel risk assessments.',
      image: 'https://cdn.abacus.ai/images/53b348fb-fb07-4d36-b468-8956345ba99d.png',
      href: '/services#protection-services'
    },
    {
      icon: Lock,
      title: 'Cyber Security & Digital Investigations',
      description: 'Advanced digital forensics, cyber threat assessment, online fraud investigation, and data breach response support.',
      image: 'https://cdn.abacus.ai/images/f9a5f296-2c6e-4fba-9eaa-f9a571632286.png',
      href: '/services#cyber-security'
    }
  ]

  return (
    <section ref={ref} className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-[#002855] mb-4">
            Comprehensive Security & Investigation Services
          </h2>
          <p className="text-xl text-[#36454F] max-w-3xl mx-auto">
            From private investigations to cyber security, we provide the full spectrum of protective services
            tailored to your specific needs.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {services?.map?.((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Link href={service?.href ?? '/services'} className="group block">
                <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 h-full">
                  <div className="relative aspect-video bg-gray-100">
                    <Image
                      src={service?.image ?? ''}
                      alt={service?.title ?? ''}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center mb-3">
                      <service.icon className="h-8 w-8 text-[#60A5FA] mr-3" />
                      <h3 className="text-2xl font-bold text-[#002855]">{service?.title ?? ''}</h3>
                    </div>
                    <p className="text-[#36454F] mb-4">{service?.description ?? ''}</p>
                    <div className="flex items-center text-[#60A5FA] font-semibold group-hover:translate-x-2 transition-transform duration-300">
                      Learn More <ArrowRight className="ml-2 h-4 w-4" />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          )) ?? []}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-12"
        >
          <Link href="/services">
            <Button size="lg" className="bg-[#002855] hover:bg-[#60A5FA] text-white px-8 py-6 text-lg">
              View All Services
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
