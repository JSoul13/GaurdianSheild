'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Shield, Search, Lock, Clock, Phone } from 'lucide-react'

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="relative w-full h-full">
          <Image
            src="https://cdn.abacus.ai/images/791bec3f-f3a2-4d31-bf3a-5a7480c03382.png"
            alt="Digital Security Shield Background"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#002855]/95 via-[#001a3a]/90 to-[#000000]/85" />
        </div>
      </div>

      {/* Content - Centered */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center text-white max-w-4xl mx-auto"
        >
          {/* Overline */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex items-center justify-center gap-2 mb-6"
          >
            <div className="w-12 h-[2px] bg-[#60A5FA]"></div>
            <span className="text-sm font-semibold tracking-wider text-gray-300 uppercase">Elite Investigation & Protection</span>
            <div className="w-12 h-[2px] bg-[#60A5FA]"></div>
          </motion.div>

          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold mb-8 leading-[1.1]">
            Your Security.<br />
            <span className="text-[#60A5FA]">Our Mission.</span>
          </h1>
          
          <p className="text-lg sm:text-xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
            Guardian Shield delivers comprehensive investigative services, executive protection, 
            and digital forensics to high-value clients across New York and beyond.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link href="/contact">
              <Button size="lg" className="bg-[#60A5FA] hover:bg-[#60A5FA]/90 text-white px-10 py-7 text-lg font-semibold shadow-xl">
                Get Confidential Consultation
              </Button>
            </Link>
            <Link href="/services">
              <Button size="lg" className="border-2 border-white text-white hover:bg-white hover:text-[#002855] bg-transparent px-10 py-7 text-lg font-semibold">
                Explore Services
              </Button>
            </Link>
          </div>

          {/* 24/7 Emergency Contact - Centered */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex items-center justify-center gap-3 text-white mb-20"
          >
            <Phone className="w-5 h-5 text-[#60A5FA]" />
            <span className="text-lg font-medium">24/7 Emergency:</span>
            <a href="tel:+18454761183" className="text-xl font-bold hover:text-[#60A5FA] transition-colors">
              +1 (845) 476-1183
            </a>
          </motion.div>
        </motion.div>

        {/* Value Propositions */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {[
            {
              icon: Shield,
              title: 'Fully Licensed & Insured',
              description: 'State of New York licensed private investigation agency'
            },
            {
              icon: Search,
              title: 'Advanced Digital Forensics',
              description: 'Cutting-edge technology for cyber investigations'
            },
            {
              icon: Lock,
              title: 'Global Network',
              description: 'International affiliations through WAD and IPIU'
            },
            {
              icon: Clock,
              title: '24/7 Availability',
              description: 'Round-the-clock support for urgent situations'
            }
          ]?.map?.((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
              className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-white/20 hover:bg-white/15 transition-all duration-300"
            >
              <item.icon className="w-10 h-10 text-[#60A5FA] mb-4" />
              <h3 className="text-lg font-bold text-white mb-2">{item?.title ?? ''}</h3>
              <p className="text-sm text-gray-300">{item?.description ?? ''}</p>
            </motion.div>
          )) ?? []}
        </motion.div>
      </div>
    </section>
  )
}
